package com.xxxx.yeb.vo;

import lombok.Data;

/**
 * @author hxxiapgy
 */
@Data
public class WebMessage {

    private String to;
    private String content;
}